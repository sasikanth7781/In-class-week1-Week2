﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;
namespace ConsoleApp4
{
    public class sk
    {
        protected int s = 2;
        void skk()
        {
            Console.WriteLine("skreddy");
        }
    }
    public class Program:sk
    {
        static void Main(string[] args)
        {
            //sk s1 = new sk();
            //Program s1 = new Program();
            //Console.WriteLine(s1.s);
            //Class1.fun();
            SpeechSynthesizer syn = new SpeechSynthesizer();
            syn.Volume = 90;
            syn.Rate = 1;
            syn.Speak("hello don your timer started");
        }
    }
}
