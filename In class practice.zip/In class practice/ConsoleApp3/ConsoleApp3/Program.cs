﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using ConsoleApp4;
namespace ConsoleApp3
{
    class sortbyname :IComparer<Program>
    {
        public int Compare(Program p1,Program p2 )
        {
            return p1.name.CompareTo(p2.name);
        }
    }
    class Program:IComparable<Program>//:sk    //ICloneable
    {
        int id;
        public string name;
        public Program(int id,string name)
        {
            this.id = id;
            this.name = name;
        }
        public int CompareTo(Program p)
        {
            return this.id.CompareTo(p.id);
        }
        /*
        static string[] si = { "A", "B", "C" };
        public string this  [int i]
        {
            set { si[i] = value; }
            //get { return si[i]; }
        }
        /*
        int x;
        public Program(int x)
        {
            
            this.x = x;

        }
        public object Clone()
        {
            return MemberwiseClone();
        }
        ~Program()
        {
            Console.WriteLine("destructure called");
        }
        static void sk()
        {
            //Program p = new Program();
        }*/
        static void Main(string[] args)
        {
            //Program.sk();
            /*GC
           
            GC.Collect();*/
            /*
            Program p = new Program();
            Console.WriteLine(p.s);*/
            /*( Program.No = 3;

             Program.No = 9;
             Console.WriteLine("{0}", Program.No);*/
            /*Program p = new Program();
            p[2] = "7";
            Console.WriteLine(p);*/
            /*
            string[] si = { "A", "B", "C" };
            CharEnumerator  sk =(CharEnumerator)si.GetEnumerator();
            while (sk.MoveNext())
            {
                Console.WriteLine(sk.Current);
            }*/
            /*
            Program p1 = new Program(4,"amogh");
            Program p2 = new Program(3,"varun");
            Program p3 = new Program(1,"sasi");
            Program[] arrp = { p1, p2, p3 };
            Console.WriteLine("before sorting");
            foreach (Program i in arrp)
            {
                Console.WriteLine(i.id);
            }
            Array.Sort(arrp);
            Console.WriteLine("after sorting");
            foreach (Program i in arrp)
            {
                Console.WriteLine(i.id);
            }
            sortbyname sbn=new sortbyname();
            Array.Sort(arrp, sbn);
            Console.WriteLine("after sorting");
            foreach (Program i in arrp)
            {
                Console.WriteLine("{0},{1}",i.id,i.name);
            }*/
            DateTime dt = DateTime.Now;
            string s = dt.ToString("HH");
            Console.WriteLine($"{s}");
        }
    }
}