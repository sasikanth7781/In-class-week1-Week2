﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class AgeLessThan20 : Exception
    {
        public AgeLessThan20(string message):base(message)
        {

        }
    }
    class OrderGreaterThan5:Exception
    {
        public OrderGreaterThan5(string message) : base(message)
        {

        }

    }
    class Program
    {
        public delegate int del(int k,int l);
        static int print1(int k, int l)
        {
            Console.WriteLine($"inside print1({k+l})");
            return k+l;
        }
        static int print2(int a,int b)
        {
            Console.WriteLine($"inside print2({a*b})");
            return a * b;
        }
        int print3(int a,int b)
        {
            Console.WriteLine($"inside print3({a-b})");
        return a - b;
        }
        static void Main(string[] args)
        {
            /*Console.WriteLine("enter age");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter number of orders");
            int orders =Convert.ToInt32(Console.ReadLine());
            try
            {
                if (age < 20)
                {
                    throw (new AgeLessThan20("user's age is less than 20"));
                }
                if (orders > 5)
                {
                    throw (new OrderGreaterThan5("number of orders greater than 5"));
                }
            }
            catch(AgeLessThan20 e)
            {
                Console.WriteLine($"{e.Message}");
            }
            catch(OrderGreaterThan5 e)
            {
                Console.WriteLine($"{e.Message }");
            }*/
            /*single casted delegate
            del del1 = Program.print1;
            del del2 = Program.print2;
            Program p = new Program();
            del del3 = p.print3;
            del1();
            del2();
            del3();*/
            //multicasted deligate
            del stmuldel = Program.print1;
            stmuldel += Program.print2;
            Program p = new Program();
            del inmuldel= p.print3;
            del all= stmuldel;
            all += inmuldel;
            all(30,25);
        }
    }
}
