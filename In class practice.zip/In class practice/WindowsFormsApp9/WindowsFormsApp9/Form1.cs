﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Font = new Font("Times New Roman", 16);
    }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text += $".";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"0";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string[] arr;
            string s = textBox1.Text;
            if (s.Contains("+")) {
                arr=s.Split('+');
                if (arr.Length > 2) {
                    textBox1.Text = "Error";
                }
                textBox1.Text =$"{Convert.ToDouble(arr[0]) + Convert.ToDouble(arr[1])}";

                    }
            else if (s.Contains("-"))
            {
                arr=s.Split('-');
                if (arr.Length > 2)
                {
                    textBox1.Text = "Error";
                }
                textBox1.Text = $"{Convert.ToDouble(arr[0]) - Convert.ToDouble(arr[1])}";


            }
            else if (s.Contains("x"))
            {
                arr=s.Split('x');
                if (arr.Length > 2)
                {
                    textBox1.Text = "Error";
                }
                textBox1.Text = $"{Convert.ToDouble(arr[0]) * Convert.ToDouble(arr[1])}";

            }
            else if (s.Contains("/"))
            {
                arr=s.Split('/');
                if (arr.Length > 2)
                {
                    textBox1.Text = "Error";
                }
                textBox1.Text = $"{Convert.ToDouble(arr[0]) / Convert.ToDouble(arr[1])}";

            }
            else
            {
                textBox1.Text = "Error occured";
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"+";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"-";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"x";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Text += $"/";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
    }
}
